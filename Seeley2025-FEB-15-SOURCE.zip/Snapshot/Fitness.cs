namespace Workshop
{
    public static class Fitness
    {
        public static float ArgmaxError(Graph graph, float[] memory, Sample[] samples)
        {
            float fitness = 0;
            float[] outputVector = new float[graph.graphOutputs.Count];
            int done = 0;
            foreach (Sample sample in samples)
            {
                graph.Forward(memory, sample.input, outputVector);
                int outputArgmax = Utility.Argmax(outputVector);
                if (outputArgmax != sample.argmax)
                {
                    fitness += 1;
                }
                done++;
                Console.Write($"\rArgmaxError: {done}/{samples.Length}");
            }
            Console.WriteLine();
            fitness /= (float)samples.Length;
            return fitness;
        }

        public static float MeanAbsoluteComponentError(Graph graph, float[] memory, Sample[] samples)
        {
            float fitness = 0;
            float[] outputVector = new float[graph.graphOutputs.Count];
            int done = 0;
            foreach (Sample sample in samples)
            {
                graph.Forward(memory, sample.input, outputVector);
                for (int i = 0; i < outputVector.Length; i++)
                {
                    fitness += MathF.Abs(outputVector[i] - sample.output[i]);
                }
                done++;
                Console.Write($"\rMeanAbsoluteComponentError: {done}/{samples.Length}");
            }
            Console.WriteLine();
            fitness /= (float)(samples.Length * samples[0].output.Length);
            return fitness;
        }

        public static float MeanAbsoluteComponentErrorParallel(Graph graph, float[] memory, Sample[] samples, int threadCount)
        {
            // create thread memories
            List<float[]> threadMemories = new List<float[]>();
            for (int i = 0; i < threadCount; i++)
            {
                threadMemories.Add((float[])memory.Clone());
            }

            // create thread outputs
            List<float[]> threadOutputs = new List<float[]>();
            for (int i = 0; i < threadCount; i++)
            {
                threadOutputs.Add(new float[graph.graphOutputs.Count]);
            }

            // create fitness results
            float[] sampleFitnesses = new float[samples.Length];

            // run threads
            int sampleIndex = 0;
            object incrementLock = new object();
            Thread[] threads = new Thread[threadCount];
            for (int threadIndex = 0; threadIndex < threadCount; threadIndex++)
            {
                int safeThreadIndex = threadIndex;
                threads[threadIndex] = new Thread(() =>
                {
                    float[] threadMemory = threadMemories[safeThreadIndex];
                    float[] threadOutput = threadOutputs[safeThreadIndex];
                    while (true)
                    {
                        int safeSampleIndex;
                        lock (incrementLock)
                        {
                            safeSampleIndex = sampleIndex++;
                            if (safeSampleIndex >= samples.Length)
                            {
                                break;
                            }
                            Console.Write($"\rMACA: {safeSampleIndex + 1}/{samples.Length}");
                        }
                        Sample sample = samples[safeSampleIndex];
                        graph.Forward(threadMemory, sample.input, threadOutput);
                        float sampleFitness = 0;
                        for (int i = 0; i < threadOutput.Length; i++)
                        {
                            sampleFitness += MathF.Abs(threadOutput[i] - sample.output[i]);
                        }
                        sampleFitnesses[safeSampleIndex] = sampleFitness;
                    }
                });
                threads[threadIndex].Start();
            }

            // join threads
            foreach (Thread thread in threads)
            {
                thread.Join();
            }
            Console.WriteLine();

            // calculate fitness
            float sum = sampleFitnesses.Sum();
            float fitness = sum / (float)(samples.Length * samples[0].output.Length);
            return fitness;
        }

        public static (float MACE, float ARGM) MACEandARGMErrorParallel(Graph graph, float[] memory, Sample[] samples, int threadCount)
        {
            // create thread memories
            List<float[]> threadMemories = new List<float[]>();
            for (int i = 0; i < threadCount; i++)
            {
                threadMemories.Add((float[])memory.Clone());
            }

            // create thread outputs
            List<float[]> threadOutputs = new List<float[]>();
            for (int i = 0; i < threadCount; i++)
            {
                threadOutputs.Add(new float[graph.graphOutputs.Count]);
            }

            // create fitness results
            float[] sampleFitnesses = new float[samples.Length];
            bool[] sampleCorrect = new bool[samples.Length];

            // run threads
            int sampleIndex = -1;
            Thread[] threads = new Thread[threadCount];
            for (int threadIndex = 0; threadIndex < threadCount; threadIndex++)
            {
                int safeThreadIndex = threadIndex;
                threads[threadIndex] = new Thread(() =>
                {
                    float[] threadMemory = threadMemories[safeThreadIndex];
                    float[] threadOutput = threadOutputs[safeThreadIndex];
                    while (true)
                    {
                        int safeSampleIndex = Interlocked.Increment(ref sampleIndex);
                        if (safeSampleIndex >= samples.Length)
                        {
                            break;
                        }
                        Sample sample = samples[safeSampleIndex];
                        graph.Forward(threadMemory, sample.input, threadOutput);
                        float sampleFitness = 0;
                        for (int i = 0; i < threadOutput.Length; i++)
                        {
                            sampleFitness += MathF.Abs(threadOutput[i] - sample.output[i]);
                        }
                        sampleFitnesses[safeSampleIndex] = sampleFitness;
                        int argmax = Utility.Argmax(threadOutput);
                        sampleCorrect[safeSampleIndex] = argmax == sample.argmax;
                    }
                });
                threads[threadIndex].Start();
            }

            // join threads
            foreach (Thread thread in threads)
            {
                thread.Join();
            }

            // calculate fitness
            float sum = sampleFitnesses.Sum();
            float MACE = sum / (float)(samples.Length * samples[0].output.Length);
            int errorCount = sampleCorrect.Count(c => !c);
            float ARGM = (float)errorCount / (float)samples.Length;
            return (MACE, ARGM);
        }
    }
}