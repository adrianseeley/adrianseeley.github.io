using Workshop.Operations;

namespace Workshop
{
    public class Graph
    {
        public delegate int ActivationFunction(int x);
        public delegate int[,,] PoolingFunction2D(int[,,] convolution, int poolSize, int stride);

        public Random random;
        public List<(int inputIndex, int memoryIndex)> graphInputs;
        public List<(int outputIndex, int memoryIndex)> graphOutputs;
        public List<(int memoryIndex, float value)> constants;
        public List<(int memoryIndex, VariableInitializer VariableInitializer)> variables;
        public List<int> memories;
        public List<Operation> operations;
        public List<List<Operation>> operationsOrder;
        public int memoryHopper;
        public bool inputsMarked;
        public bool outputsMarked;
        public bool compiled;

        public Graph()
        {
            this.random = new Random();
            this.graphInputs = new List<(int inputIndex, int memoryIndex)>();
            this.graphOutputs = new List<(int outputIndex, int memoryIndex)>();
            this.constants = new List<(int memoryIndex, float value)>();
            this.variables = new List<(int memoryIndex, VariableInitializer variableInitializer)>();
            this.memories = new List<int>();
            this.operations = new List<Operation>();
            this.operationsOrder = new List<List<Operation>>();
            this.memoryHopper = 0;
            this.inputsMarked = false;
            this.outputsMarked = false;
            this.compiled = false;
        }

        public void Compile()
        {
            int done;

            // clear any existing order
            operationsOrder.Clear();

            // make a list of computed values
            HashSet<int> valuesComputed = new HashSet<int>();

            // make a list of values remaining
            HashSet<int> valuesRemaining = new HashSet<int>(Enumerable.Range(0, memoryHopper));

            // add all inputs to computed
            done = 0;
            foreach ((int inputIndex, int memoryIndex) in graphInputs)
            {
                valuesComputed.Add(memoryIndex);
                valuesRemaining.Remove(memoryIndex);
                done++;
                Console.Write($"\rCompiling: gathering graph inputs {done} / {graphInputs.Count}");
            }
            Console.WriteLine();

            // add all constants to computed
            done = 0;
            foreach ((int memoryIndex, float value) in constants)
            {
                valuesComputed.Add(memoryIndex);
                valuesRemaining.Remove(memoryIndex);
                done++;
                Console.Write($"\rCompiling: gathering constants {done} / {constants.Count}");
            }
            Console.WriteLine();

            // add all variables that arent computed to computed
            done = 0;
            HashSet<int> operationOutputs = new HashSet<int>();
            foreach (Operation operation in operations)
            {
                operationOutputs.UnionWith(operation.outputs);
            }
            foreach ((int memoryIndex, VariableInitializer variableInitializer) in variables)
            {
                if (!operationOutputs.Contains(memoryIndex))
                {
                    valuesComputed.Add(memoryIndex);
                    valuesRemaining.Remove(memoryIndex);
                }
                done++;
                Console.Write($"\rCompiling: gathering variables {done} / {variables.Count}");
            }
            Console.WriteLine();

            // make a list of remaining operations
            List<Operation> operationsRemaining = new List<Operation>(operations);

            // establish forward order
            done = 0;
            while (operationsRemaining.Count > 0)
            {
                // if no operations are reduced we have an error
                int operationsReduced = 0;

                // track values computed this layer
                HashSet<int> valuesComputedThisLayer = new HashSet<int>();

                // track operations that can execute this layer
                List<Operation> operationLayer = new List<Operation>();

                // iterate remaining operations
                for (int operationRemainingIndex = 0; operationRemainingIndex < operationsRemaining.Count; operationRemainingIndex++)
                {
                    // get operation
                    Operation operationRemaining = operationsRemaining[operationRemainingIndex];

                    // if all the input for this operation are computed
                    if (operationRemaining.inputs.Select(input => input).All(valuesComputed.Contains)) // todo this could be a is perfect subset of i think
                    {
                        // add operation to layer
                        operationLayer.Add(operationRemaining);

                        // remove operation from remaining
                        operationsRemaining.RemoveAt(operationRemainingIndex);

                        // jog iterator back to compensate for removal
                        operationRemainingIndex--;

                        done++;
                        Console.Write($"\rCompiling: establishing forward order {done} / {operations.Count}");

                        // add output to computed
                        foreach (int scalar in operationRemaining.outputs)
                        {
                            valuesComputedThisLayer.Add(scalar);
                        }

                        // tally operations reduced
                        operationsReduced++;
                    }
                }

                // add layer to order
                operationsOrder.Add(operationLayer);

                // add values computed this layer to computed
                valuesComputed.UnionWith(valuesComputedThisLayer);

                // remove values computed this layer from remaining
                valuesRemaining.ExceptWith(valuesComputedThisLayer);

                // if no operations were reduced this layer we have an error
                if (operationsReduced == 0)
                {
                    throw new Exception("Could not establish forward order (dangling operations)");
                }
            }

            // if there are any values remaining we have an error
            if (valuesRemaining.Count > 0)
            {
                throw new Exception("Could not establish forward order (dangling values)");
            }
            Console.WriteLine();

            // mark as compiled
            compiled = true;
        }

        public float[] CreateMemory()
        {
            if (!compiled)
            {
                throw new Exception("Graph must be compiled before creating memory");
            }

            // create memory
            float[] memory = new float[memoryHopper];

            // initialize variables
            foreach ((int memoryIndex, VariableInitializer variableInitializer) in variables)
            {
                memory[memoryIndex] = variableInitializer.Next(random);
            }

            // return memory
            return memory;
        }

        public float[] CreateMemoryGradient()
        {
            if (!compiled)
            {
                throw new Exception("Graph must be compiled before creating memory gradient");
            }
            return new float[memoryHopper];
        }

        public void Forward(float[] memory, float[] inputVector, float[] outputVector)
        {
            if (!compiled)
            {
                throw new Exception("Graph must be compiled before forward pass");
            }

            // copy input into memory
            foreach ((int inputIndex, int scalar) in graphInputs)
            {
                memory[scalar] = inputVector[inputIndex];
            }

            // copy constants into memory
            foreach ((int memoryIndex, float value) in constants)
            {
                memory[memoryIndex] = value;
            }

            // forward pass
            foreach (List<Operation> operationLayer in operationsOrder)
            {
                foreach (Operation operation in operationLayer)
                {
                    operation.Forward(memory);
                }
            }

            // copy output out of memory
            foreach ((int outputIndex, int memoryIndex) in graphOutputs)
            {
                outputVector[outputIndex] = memory[memoryIndex];
            }
        }

        public void ForwardDropout(float[] memory, float[] inputVector, float[] outputVector, float dropoutRate)
        {
            if (!compiled)
            {
                throw new Exception("Graph must be compiled before forward pass");
            }

            // copy input into memory
            foreach ((int inputIndex, int scalar) in graphInputs)
            {
                memory[scalar] = inputVector[inputIndex];
            }

            // copy constants into memory
            foreach ((int memoryIndex, float value) in constants)
            {
                memory[memoryIndex] = value;
            }

            // forward pass
            foreach (List<Operation> operationLayer in operationsOrder)
            {
                foreach (Operation operation in operationLayer)
                {
                    operation.Forward(memory);
                    foreach (int outputMemoryIndex in operation.outputs)
                    {
                        if (random.NextSingle() < dropoutRate)
                        {
                            memory[outputMemoryIndex] = 0;
                        }
                    }
                }
            }

            // copy output out of memory
            foreach ((int outputIndex, int memoryIndex) in graphOutputs)
            {
                outputVector[outputIndex] = memory[memoryIndex];
            }
        }

        public void Gradient(float[] memory, float[] memoryGradient, float[] outputGradient)
        {
            if (!compiled)
            {
                throw new Exception("Graph must be compiled before backward pass");
            }

            // memory is assumed to already contain the input and output vectors

            // zero out gradients
            Array.Clear(memoryGradient, 0, memoryHopper);

            // place output gradients
            foreach ((int outputIndex, int scalar) in graphOutputs)
            {
                memoryGradient[scalar] = outputGradient[outputIndex];
            }

            // backward pass
            for (int layerIndex = operationsOrder.Count - 1; layerIndex >= 0; layerIndex--)
            {
                List<Operation> layer = operationsOrder[layerIndex];
                foreach (Operation operation in layer)
                {
                    operation.Gradient(memory, memoryGradient);
                }
            }
        }

        public List<float> GetVariableValues(float[] memory)
        {
            if (!compiled)
            {
                throw new Exception("Graph must be compiled before getting variable values");
            }

            List<float> variableValues = new List<float>();
            foreach ((int memoryIndex, VariableInitializer variableInitializer) in variables)
            {
                variableValues.Add(memory[memoryIndex]);
            }
            return variableValues;
        }

        public int Memory()
        {
            int memoryIndex = memoryHopper++;
            memories.Add(memoryIndex);
            return memoryIndex;
        }

        public List<int> Memories(int count)
        {
            List<int> memoryIndices = new List<int>();
            for (int i = 0; i < count; i++)
            {
                memoryIndices.Add(Memory());
            }
            return memoryIndices;
        }

        public int Constant(float value)
        {
            int memoryIndex = Memory();
            constants.Add((memoryIndex, value));
            return memoryIndex;
        }

        public int Variable(VariableInitializer variableInitializer)
        {
            int memoryIndex = Memory();
            variables.Add((memoryIndex, variableInitializer));
            return memoryIndex;
        }

        public List<int> Variables(int count, VariableInitializer variableInitializer)
        {
            List<int> memoryIndices = new List<int>();
            for (int i = 0; i < count; i++)
            {
                memoryIndices.Add(Variable(variableInitializer));
            }
            return memoryIndices;
        }

        public int GraphInput()
        {
            if (inputsMarked)
            {
                throw new Exception("Graph inputs already marked");
            }
            inputsMarked = true;
            int memoryIndex = Memory();
            graphInputs.Add((0, memoryIndex));
            return memoryIndex;
        }

        public List<int> GraphInputs(int count)
        {
            List<int> memoryIndices = new List<int>();
            for (int i = 0; i < count; i++)
            {
                int memoryIndex = Memory();
                graphInputs.Add((i, memoryIndex));
                memoryIndices.Add(memoryIndex);
            }
            return memoryIndices;
        }

        public void GraphOutputs(List<int> memoryIndices)
        {
            for (int i = 0; i < memoryIndices.Count; i++)
            {
                int memoryIndex = memoryIndices[i];
                graphOutputs.Add((i, memoryIndex));
            }
        }

        public int Plus(List<int> values)
        {
            int y = Memory();
            operations.Add(new Plus(values, y));
            return y;
        }

        public int Plus(int a, int b)
        {
            return Plus([a, b]);
        }

        public List<int> PlusVectors(List<List<int>> vectors)
        {
            List<int> sumVector = new List<int>();
            for (int componentIndex = 0; componentIndex < vectors[0].Count; componentIndex++)
            {
                List<int> componentValues = new List<int>();
                for (int vectorIndex = 0; vectorIndex < vectors.Count; vectorIndex++)
                {
                    componentValues.Add(vectors[vectorIndex][componentIndex]);
                }
                sumVector.Add(Plus(componentValues));
            }
            return sumVector;
        }

        public int Minus(int a, int b)
        {
            int y = Memory();
            operations.Add(new Minus(a, b, y));
            return y;
        }

        public int Multiply(List<int> vector)
        {
            int y = Memory();
            operations.Add(new Multiply(vector, y));
            return y;
        }

        public int Multiply(int a, int b)
        {
            return Multiply([a, b]);
        }

        public List<int> MultiplyVectorByScalar(List<int> vector, int scalar)
        {
            List<int> productVector = new List<int>();
            for (int i = 0; i < vector.Count; i++)
            {
                productVector.Add(Multiply(vector[i], scalar));
            }
            return productVector;
        }

        public List<int> MultiplyVectorByVector(List<int> vectorA, List<int> vectorB)
        {
            List<int> productVector = new List<int>();
            for (int i = 0; i < vectorA.Count; i++)
            {
                productVector.Add(Multiply(vectorA[i], vectorB[i]));
            }
            return productVector;
        }

        public List<List<int>> MultiplyVectorsByVector(List<List<int>> a, List<int> b)
        {
            List<List<int>> vectorProducts = new List<List<int>>();
            for (int i = 0; i < a.Count; i++)
            {
                vectorProducts.Add(MultiplyVectorByVector(a[i], b));
            }
            return vectorProducts;
        }

        public List<List<int>> MultiplyVectorsByScalars(List<List<int>> a, List<int> b)
        {
            List<List<int>> vectorProducts = new List<List<int>>();
            for (int i = 0; i < a.Count; i++)
            {
                vectorProducts.Add(MultiplyVectorByScalar(a[i], b[i]));
            }
            return vectorProducts;
        }

        public int Divide(int a, int b)
        {
            int y = Memory();
            operations.Add(new Divide(a, b, y));
            return y;
        }

        public List<int> DivideVectorByScalar(List<int> a, int b)
        {
            List<int> quotientVector = new List<int>();
            for (int i = 0; i < a.Count; i++)
            {
                quotientVector.Add(Divide(a[i], b));
            }
            return quotientVector;
        }

        public int Power(int a, int b)
        {
            int y = Memory();
            operations.Add(new Power(a, b, y));
            return y;
        }

        public int Square(int x)
        {
            int y = Memory();
            operations.Add(new Square(x, y));
            return y;
        }

        public int SquareRoot(int x)
        {
            int y = Memory();
            operations.Add(new SquareRoot(x, y));
            return y;
        }

        public int Absolute(int x)
        {
            int y = Memory();
            operations.Add(new Absolute(x, y));
            return y;
        }

        public int Max(List<int> xs)
        {
            int y = Memory();
            operations.Add(new Max(xs, y));
            return y;
        }

        public (int y, int index) MaxWithIndex(List<int> xs)
        {
            int y = Memory();
            int index = Memory();
            operations.Add(new MaxWithIndex(xs, y, index));
            return (y, index);
        }

        public int Min(List<int> xs)
        {
            int y = Memory();
            operations.Add(new Min(xs, y));
            return y;
        }

        public (int y, int index) MinWithIndex(List<int> xs)
        {
            int y = Memory();
            int index = Memory();
            operations.Add(new MinWithIndex(xs, y, index));
            return (y, index);
        }

        public int Average(List<int> xs)
        {
            int y = Memory();
            operations.Add(new Average(xs, y));
            return y;
        }

        public int Dot(List<int> a, List<int> b)
        {
            return Plus(MultiplyVectorByVector(a, b));
        }

        public int Sin(int x)
        {
            int y = Memory();
            operations.Add(new Sin(x, y));
            return y;
        }

        public int Cos(int x)
        {
            int y = Memory();
            operations.Add(new Cos(x, y));
            return y;
        }

        public int Tan(int y)
        {
            int x = Memory();
            operations.Add(new Tan(x, y));
            return x;
        }

        public int TanH(int x)
        {
            int y = Memory();
            operations.Add(new TanH(x, y));
            return y;
        }

        public int Sigmoid(int x)
        {
            int y = Memory();
            operations.Add(new Sigmoid(x, y));
            return y;
        }

        public int ReLu(int x)
        {
            int y = Memory();
            operations.Add(new ReLu(x, y));
            return y;
        }

        public int LeakyReLu(int x, int leakiness)
        {
            int y = Memory();
            operations.Add(new LeakyReLu(x, leakiness, y));
            return y;
        }

        public int DistanceEuclidean(List<int> a, List<int> b)
        {
            List<int> squares = new List<int>();
            for (int i = 0; i < a.Count; i++)
            {
                squares.Add(Square(Minus(a[i], b[i])));
            }
            return SquareRoot(Plus(squares));
        }

        public int WeightedSum(List<int> vector, VariableInitializer weightInitializer)
        {
            return Plus(MultiplyVectorByVector(vector, Variables(vector.Count, weightInitializer)));
        }

        public int WeightedSumWithBias(List<int> vector, VariableInitializer weightInitializer, VariableInitializer biasInitializer)
        {
            return Plus(WeightedSum(vector, weightInitializer), Variable(biasInitializer));
        }

        public List<int> WeightedAverage(List<List<int>> vectors, List<int> weights)
        {
            return DivideVectorByScalar(PlusVectors(MultiplyVectorsByScalars(vectors, weights)), Plus(weights));
        }

        public int Neuron(List<int> vector, VariableInitializer weightInitializer, VariableInitializer biasInitializer, ActivationFunction activationFunction)
        {
            return activationFunction(WeightedSumWithBias(vector, weightInitializer, biasInitializer));
        }

        public List<int> NeuronLayer(List<int> vector, int neuronCount, VariableInitializer weightInitializer, VariableInitializer biasInitializer, ActivationFunction activationFunction)
        {
            List<int> neurons = new List<int>();
            for (int i = 0; i < neuronCount; i++)
            {
                neurons.Add(Neuron(vector, weightInitializer, biasInitializer, activationFunction));
            }
            return neurons;
        }

        public List<int> FullyConnectedNeuronBlock(List<int> vector, int layerCount, int neuronCount, VariableInitializer weightInitializer, VariableInitializer biasInitializer, ActivationFunction activationFunction)
        {
            List<int> lastInputs = vector;
            for (int i = 0; i < layerCount; i++)
            {
                lastInputs = NeuronLayer(lastInputs, neuronCount, weightInitializer, biasInitializer, activationFunction);
            }
            return lastInputs;
        }

        public (List<int> finalLayerOutputs, List<int> allOutputs) RandomConnectedNeuronBlock(List<int> vector, int layerCount, int neuronCount, int neuronInputCount, VariableInitializer weightInitializer, VariableInitializer biasInitializer, ActivationFunction activationFunction)
        {
            // create a pool of all available inputs
            List<int> inputPool = new List<int>(vector);

            // create a pool of all outputs (includes the input vector passthrough)
            List<int> outputPool = new List<int>(vector);

            // create a pool of the final layer outputs
            List<int> finalLayerOutputs = new List<int>();

            // iterate layers
            for (int layerIndex = 0; layerIndex < layerCount; layerIndex++)
            {
                // create a list of inputs to add back to the pool
                List<int> inputsToAdd = new List<int>();

                // iterate through neurons
                for (int neuronIndex = 0; neuronIndex < neuronCount; neuronIndex++)
                {
                    // randomly select inputs (note that if there arent enough inputs all will be taken with no duplicates)
                    List<int> neuronInputs = inputPool.OrderBy(x => random.Next()).Take(neuronInputCount).ToList();

                    // create the neuron
                    int neuronOutput = Neuron(neuronInputs, weightInitializer, biasInitializer, activationFunction);

                    // add the output to the output pool
                    outputPool.Add(neuronOutput);

                    // if this is the final layer, add the output to the final layer outputs
                    if (layerIndex == layerCount - 1)
                    {
                        finalLayerOutputs.Add(neuronOutput);
                    }

                    // add the output to the inputs to add pool
                    inputsToAdd.Add(neuronOutput);
                }

                // update the input pool
                inputPool.AddRange(inputsToAdd);
            }

            // return the final layer outputs and all outputs
            return (finalLayerOutputs, outputPool);
        }

        public (List<int[,,]> windows, int windowsWide, int windowsHigh) Window2D(int[,,] image, int windowSize, int stride, int padding)
        {
            // get input dimensions
            int width = image.GetLength(0);
            int height = image.GetLength(1);
            int dimensions = image.GetLength(2);

            // compute padded dimensions
            int paddedWidth = width + 2 * padding;
            int paddedHeight = height + 2 * padding;

            // compute output dimensions:
            // (paddedDimension - windowSize) / stride + 1
            int windowsWide = ((paddedWidth - windowSize) / stride) + 1;
            int windowsHigh = ((paddedHeight - windowSize) / stride) + 1;

            // allocate windows
            List<int[,,]> windows = new List<int[,,]>();

            // loop over each window index
            for (int windowXIndex = 0; windowXIndex < windowsWide; windowXIndex++)
            {
                for (int windowYIndex = 0; windowYIndex < windowsHigh; windowYIndex++)
                {
                    // determine the starting coordinates in the padded coordinate system
                    int startX = windowXIndex * stride - padding;
                    int startY = windowYIndex * stride - padding;

                    // create a window of shape [windowSize, windowSize, dimensions]
                    int[,,] window = new int[windowSize, windowSize, dimensions];

                    // fill window
                    for (int x = 0; x < windowSize; x++)
                    {
                        for (int y = 0; y < windowSize; y++)
                        {
                            for (int d = 0; d < dimensions; d++)
                            {
                                // calculate the source coordinates
                                int sourceX = startX + x;
                                int sourceY = startY + y;

                                // if out-of-bounds, use constant 0, otherwise get value from image
                                if (sourceX < 0 || sourceX >= width || sourceY < 0 || sourceY >= height)
                                {
                                    window[x, y, d] = Constant(0);
                                }
                                else
                                {
                                    window[x, y, d] = image[sourceX, sourceY, d];
                                }
                            }
                        }
                    }
                    windows.Add(window);
                }
            }

            return (windows, windowsWide, windowsHigh);
        }

        public int[,,] Convolution2D(int width, int height, List<int[,,]> windows, int kernelCount, VariableInitializer weightInitializer, VariableInitializer biasInitializer)
        {
            int[,,] convolution = new int[width, height, kernelCount];
            for (int kernel = 0; kernel < kernelCount; kernel++)
            {
                List<int> kernelWeights = Variables(windows[0].Length, weightInitializer);
                int kernelBias = Variable(biasInitializer);
                int windowX = 0;
                int windowY = 0;
                for (int windowIndex = 0; windowIndex < windows.Count; windowIndex++)
                {
                    int kernelWeightIndex = 0;
                    List<int> toSum = new List<int>() { kernelBias };
                    for (int x = 0; x < windows[windowIndex].GetLength(0); x++)
                    {
                        for (int y = 0; y < windows[windowIndex].GetLength(1); y++)
                        {
                            for (int dimension = 0; dimension < windows[windowIndex].GetLength(2); dimension++)
                            {
                                int componentValue = windows[windowIndex][x, y, dimension];
                                toSum.Add(Multiply(componentValue, kernelWeights[kernelWeightIndex++]));
                            }
                        }
                    }
                    int kernelOutput = Plus(toSum);
                    convolution[windowX, windowY, kernel] = kernelOutput;
                    windowX++;
                    if (windowX == width)
                    {
                        windowX = 0;
                        windowY++;
                    }
                }
            }
            return convolution;
        }

        public int[,,] MaxPooling2D(int[,,] convolution, int poolSize, int stride)
        {
            // get dimensions of the convolution output
            int inputWidth = convolution.GetLength(0);
            int inputHeight = convolution.GetLength(1);
            int channels = convolution.GetLength(2);

            // compute pooled output dimensions
            int pooledWidth = ((inputWidth - poolSize) / stride) + 1;
            int pooledHeight = ((inputHeight - poolSize) / stride) + 1;

            // allocate output array for pooled feature maps.
            int[,,] pooled = new int[pooledWidth, pooledHeight, channels];

            // iterate channels in convolution
            for (int channel = 0; channel < channels; channel++)
            {
                // slide pooling window over spatial dimensions
                for (int poolX = 0; poolX < pooledWidth; poolX++)
                {
                    for (int poolY = 0; poolY < pooledHeight; poolY++)
                    {
                        // compute the starting indices for this window in the input
                        int startX = poolX * stride;
                        int startY = poolY * stride;

                        // gather all values to max on
                        List<int> toMax = new List<int>();

                        // iterate over the pooling size
                        for (int x = 0; x < poolSize; x++)
                        {
                            for (int y = 0; y < poolSize; y++)
                            {
                                int convolutionX = startX + x;
                                int convolutionY = startY + y;
                                toMax.Add(convolution[convolutionX, convolutionY, channel]);
                            }
                        }

                        // calculate the max value into the pool
                        pooled[poolX, poolY, channel] = Max(toMax);
                    }
                }
            }


            // return max pooled
            return pooled;
        }

        public int[,,] AveragePooling2D(int[,,] convolution, int poolSize, int stride)
        {
            // get dimensions of the convolution output
            int inputWidth = convolution.GetLength(0);
            int inputHeight = convolution.GetLength(1);
            int channels = convolution.GetLength(2);

            // compute pooled output dimensions
            int pooledWidth = ((inputWidth - poolSize) / stride) + 1;
            int pooledHeight = ((inputHeight - poolSize) / stride) + 1;

            // allocate output array for pooled feature maps.
            int[,,] pooled = new int[pooledWidth, pooledHeight, channels];

            // iterate channels in convolution
            for (int channel = 0; channel < channels; channel++)
            {
                // slide pooling window over spatial dimensions
                for (int poolX = 0; poolX < pooledWidth; poolX++)
                {
                    for (int poolY = 0; poolY < pooledHeight; poolY++)
                    {
                        // compute the starting indices for this window in the input
                        int startX = poolX * stride;
                        int startY = poolY * stride;

                        // gather all values to average on
                        List<int> toAverage = new List<int>();

                        // iterate over the pooling size
                        for (int x = 0; x < poolSize; x++)
                        {
                            for (int y = 0; y < poolSize; y++)
                            {
                                int convolutionX = startX + x;
                                int convolutionY = startY + y;
                                toAverage.Add(convolution[convolutionX, convolutionY, channel]);
                            }
                        }

                        // calculate the average value into the pool
                        pooled[poolX, poolY, channel] = Average(toAverage);
                    }
                }
            }

            // return average pooled
            return pooled;
        }

        public int[,,] ConvolutionActivationPooling2D(int[,,] image, int windowSize, int windowStride, int windowPadding, int kernelCount, int poolSize, int poolStride, ActivationFunction activationFunction, PoolingFunction2D poolingFunction, VariableInitializer weightInitializer, VariableInitializer biasInitializer)
        {
            (List<int[,,]> windows, int windowsWide, int windowsHigh) = Window2D(image, windowSize, windowStride, windowPadding);
            int[,,] convolution = Convolution2D(windowsWide, windowsHigh, windows, kernelCount, weightInitializer, biasInitializer);
            for (int x = 0; x < convolution.GetLength(0); x++)
            {
                for (int y = 0; y < convolution.GetLength(1); y++)
                {
                    for (int d = 0; d < convolution.GetLength(2); d++)
                    {
                        convolution[x, y, d] = activationFunction(convolution[x, y, d]);
                    }
                }
            }
            return poolingFunction(convolution, poolSize, poolStride);
        }

        public int[,,] ReshapeToImage(List<int> vector, int width, int height, int dimensions)
        {
            int[,,] image = new int[width, height, dimensions];
            int vectorIndex = 0;
            for (int x = 0; x < width; x++)
            {
                for (int y = 0; y < height; y++)
                {
                    for (int d = 0; d < dimensions; d++)
                    {
                        image[x, y, d] = vector[vectorIndex++];
                    }
                }
            }
            return image;
        }

        public List<int> ReshapeToVector(int[,,] image)
        {
            List<int> vector = new List<int>();
            for (int x = 0; x < image.GetLength(0); x++)
            {
                for (int y = 0; y < image.GetLength(1); y++)
                {
                    for (int d = 0; d < image.GetLength(2); d++)
                    {
                        vector.Add(image[x, y, d]);
                    }
                }
            }
            return vector;
        }
    }
}