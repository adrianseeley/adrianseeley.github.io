﻿namespace Workshop.GradientModifying
{
    public class GradientClip : GradientModifier
    {
        public float clipValue;

        public GradientClip(float clipValue)
        {
            this.clipValue = clipValue;
        }

        public override void Modify(int epoch, float[] memory, float[] memoryGradient)
        {
            for (int i = 0; i < memoryGradient.Length; i++)
            {
                if (memoryGradient[i] > clipValue)
                {
                    memoryGradient[i] = clipValue;
                }
                else if (memoryGradient[i] < -clipValue)
                {
                    memoryGradient[i] = -clipValue;
                }
            }
        }
    }
}
