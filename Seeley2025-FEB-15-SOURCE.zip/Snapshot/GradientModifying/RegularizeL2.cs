﻿namespace Workshop.GradientModifying
{
    public class RegularizeL2 : GradientModifier
    {
        public float lambda;

        public RegularizeL2(float lambda)
        {
            this.lambda = lambda;
        }

        public override void Modify(int epoch, float[] memory, float[] memoryGradient)
        {
            for (int i = 0; i < memoryGradient.Length; i++)
            {
                memoryGradient[i] -= 2 * lambda * memory[i];
            }
        }
    }
}
