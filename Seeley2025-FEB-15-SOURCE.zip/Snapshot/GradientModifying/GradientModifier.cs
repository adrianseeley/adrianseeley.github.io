﻿namespace Workshop.GradientModifying
{
    public abstract class GradientModifier
    {
        public int configurationLength;

        public virtual void Setup(int configurationLength)
        {
            this.configurationLength = configurationLength;
        }

        public abstract void Modify(int epoch, float[] memory, float[] memoryGradient);
    }
}
