﻿namespace Workshop.GradientModifying
{
    public class RegularizeL1 : GradientModifier
    {
        public float lambda;

        public RegularizeL1(float lambda)
        {
            this.lambda = lambda;
        }

        public override void Modify(int epoch, float[] memory, float[] memoryGradient)
        {
            for (int i = 0; i < memoryGradient.Length; i++)
            {
                memoryGradient[i] -= lambda * MathF.Sign(memory[i]);
            }
        }
    }
}
