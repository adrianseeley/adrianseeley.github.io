namespace Workshop.GradientModifying
{
    public class RegularizeL1L2 : GradientModifier
    {
        public float alpha;  // L1 coefficient
        public float beta;   // L2 coefficient

        public RegularizeL1L2(float alpha, float beta)
        {
            this.alpha = alpha;
            this.beta = beta;
        }

        public override void Modify(int epoch, float[] memory, float[] memoryGradient)
        {
            for (int i = 0; i < memoryGradient.Length; i++)
            {
                memoryGradient[i] -= alpha * MathF.Sign(memory[i]) + beta * 2 * memory[i];
            }
        }
    }
}
