﻿namespace Workshop.GradientModifying
{
    public class LearningRate : GradientModifier
    {
        public float learningRate;

        public LearningRate(float learningRate)
        {
            this.learningRate = learningRate;
        }
        public override void Modify(int epoch, float[] memory, float[] memoryGradient)
        {
            for (int i = 0; i < memoryGradient.Length; i++)
            {
                memoryGradient[i] *= learningRate;
            }
        }
    }
}
