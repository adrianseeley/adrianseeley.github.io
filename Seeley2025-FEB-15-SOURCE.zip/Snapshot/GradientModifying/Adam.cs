﻿namespace Workshop.GradientModifying
{
    public class Adam : GradientModifier
    {
        public float beta1;
        public float beta2;
        public float epsilon;
        public float[] m;
        public float[] v;

        public Adam(float beta1 = 0.9f, float beta2 = 0.999f, float epsilon = 1e-8f)
        {
            this.beta1 = beta1;
            this.beta2 = beta2;
            this.epsilon = epsilon;
            this.m = new float[0];
            this.v = new float[0];
        }

        public override void Setup(int memoryLength)
        {
            base.Setup(memoryLength);
            m = new float[memoryLength];
            v = new float[memoryLength];
        }

        public override void Modify(int epoch, float[] memory, float[] memoryGradient)
        {
            int t = epoch + 1;
            for (int i = 0; i < memory.Length; i++)
            {
                // update biased moments
                m[i] = beta1 * m[i] + (1 - beta1) * memoryGradient[i];
                v[i] = beta2 * v[i] + (1 - beta2) * (memoryGradient[i] * memoryGradient[i]);

                // compute bias-corrected moments
                float mHat = m[i] / (1 - MathF.Pow(beta1, t));
                float vHat = v[i] / (1 - MathF.Pow(beta2, t));

                // update gradient
                memoryGradient[i] = mHat / (MathF.Sqrt(vHat) + epsilon);
            }
        }
    }
}
