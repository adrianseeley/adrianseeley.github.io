namespace Workshop
{
    public delegate void LossFunction(float[] prediction, float[] target, float[] outputGradient);

    public static class Loss
    {
        public static void Absolute(float[] prediction, float[] target, float[] outputGradient)
        {
            for (int i = 0; i < prediction.Length; i++)
            {
                float difference = prediction[i] - target[i];
                if (difference > 0)
                {
                    outputGradient[i] = 1;
                }
                else if (difference < 0)
                {
                    outputGradient[i] = -1;
                }
                else
                {
                    outputGradient[i] = 0;
                }
            }
        }

        public static void Squared(float[] prediction, float[] target, float[] outputGradient)
        {
            for (int i = 0; i < prediction.Length; i++)
            {
                outputGradient[i] = 2 * (prediction[i] - target[i]);
            }
        }

        public static void CrossEntropy(float[] prediction, float[] target, float[] outputGradient)
        {
            for (int i = 0; i < prediction.Length; i++)
            {
                outputGradient[i] = -target[i] / prediction[i];
            }
        }
    }
}