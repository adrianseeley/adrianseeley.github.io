﻿namespace Workshop.Operations
{
    public class Power : Operation
    {
        public int a;
        public int b;
        public int y;

        public Power(int a, int b, int y)
            : base([a, b], [y])
        {
            this.a = a;
            this.b = b;
            this.y = y;
        }

        public override void Forward(float[] memory)
        {
            float aValue = memory[a];
            float bValue = memory[b];
            memory[y] = MathF.Pow(MathF.Abs(aValue), bValue) * MathF.Sign(aValue);
        }

        public override void Gradient(float[] memory, float[] memoryGradient)
        {
            float aValue = memory[a];
            float bValue = memory[b];
            float yGradient = memoryGradient[y];
            if (aValue == 0)
            {
                aValue = 1e-10f; // prevent divide by zero
            }
            memoryGradient[a] += yGradient * bValue * MathF.Pow(MathF.Abs(aValue), bValue - 1) * MathF.Sign(aValue);
            memoryGradient[b] += yGradient * MathF.Pow(MathF.Abs(aValue), bValue) * MathF.Log(MathF.Abs(aValue));
        }
    }
}
