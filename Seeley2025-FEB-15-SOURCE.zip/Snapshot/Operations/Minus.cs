﻿namespace Workshop.Operations
{
    public class Minus : Operation
    {
        public int a;
        public int b;
        public int y;

        public Minus(int a, int b, int y)
            : base([a, b], [y])
        {
            this.a = a;
            this.b = b;
            this.y = y;
        }

        public override void Forward(float[] memory)
        {
            memory[y] = memory[a] - memory[b];
        }

        public override void Gradient(float[] memory, float[] memoryGradient)
        {
            memoryGradient[a] += memoryGradient[y];
            memoryGradient[b] -= memoryGradient[y];
        }
    }
}
