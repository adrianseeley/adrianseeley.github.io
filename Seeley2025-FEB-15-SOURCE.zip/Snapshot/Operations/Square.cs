﻿namespace Workshop.Operations
{
    public class Square : Operation
    {
        public int x;
        public int y;

        public Square(int x, int y)
            : base([x], [y])
        {
            this.x = x;
            this.y = y;
        }

        public override void Forward(float[] memory)
        {
            memory[y] = memory[x] * memory[x];
        }

        public override void Gradient(float[] memory, float[] memoryGradient)
        {
            memoryGradient[x] += memoryGradient[y] * 2 * memory[y];
        }
    }
}
