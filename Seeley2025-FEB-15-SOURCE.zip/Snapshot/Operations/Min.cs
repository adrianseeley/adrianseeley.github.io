﻿namespace Workshop.Operations
{
    public class Min : Operation
    {
        public List<int> xs;
        public int y;

        public Min(List<int> xs, int y)
            : base(xs, [y])
        {
            this.xs = xs;
            this.y = y;
        }

        public override void Forward(float[] memory)
        {
            float min = float.MaxValue;
            foreach (int x in xs)
            {
                min = MathF.Min(min, memory[x]);
            }
            memory[y] = min;
        }

        public override void Gradient(float[] memory, float[] memoryGradient)
        {
            float min = memory[y];
            foreach (int x in xs)
            {
                if (memory[x] == min)
                {
                    memoryGradient[x] += memoryGradient[y];
                }
                else
                {
                    memoryGradient[x] += 0;
                }
            }
        }
    }
}
