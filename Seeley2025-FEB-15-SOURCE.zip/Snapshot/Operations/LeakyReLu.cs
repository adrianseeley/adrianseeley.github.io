﻿namespace Workshop.Operations
{
    public class LeakyReLu : Operation
    {
        public int x;
        public int leakiness;
        public int y;

        public LeakyReLu(int x, int leakiness, int y)
            : base([x, leakiness], [y])
        {
            this.x = x;
            this.leakiness = leakiness;
            this.y = y;
        }

        public override void Forward(float[] memory)
        {
            memory[y] = memory[x] > 0 ? memory[x] : memory[x] * memory[leakiness];
        }

        public override void Gradient(float[] memory, float[] memoryGradient)
        {
            memoryGradient[x] += memoryGradient[y] * (memory[x] > 0 ? 1 : memory[leakiness]);
            memoryGradient[leakiness] += memoryGradient[y] * (memory[x] > 0 ? 0 : memory[x]);
        }
    }
}
