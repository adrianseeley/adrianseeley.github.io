﻿namespace Workshop.Operations
{
    public class Absolute : Operation
    {
        public int x;
        public int y;

        public Absolute(int x, int y)
            : base([x], [y])
        {
            this.x = x;
            this.y = y;
        }

        public override void Forward(float[] memory)
        {
            memory[y] = MathF.Abs(memory[x]);
        }

        public override void Gradient(float[] memory, float[] memoryGradient)
        {
            if (memory[x] > 0)
            {
                memoryGradient[x] += memoryGradient[y];
            }
            else if (memory[x] < 0)
            {
                memoryGradient[x] -= memoryGradient[y];
            }
            else
            {
                memoryGradient[x] += 0;
            }
        }
    }
}
