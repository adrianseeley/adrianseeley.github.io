﻿namespace Workshop.Operations
{
    public class TanH : Operation
    {
        public int x;
        public int y;

        public TanH(int x, int y)
            : base([x], [y])
        {
            this.x = x;
            this.y = y;
        }

        public override void Forward(float[] memory)
        {
            memory[y] = MathF.Tanh(memory[x]);
        }

        public override void Gradient(float[] memory, float[] memoryGradient)
        {
            float tanh = memory[y];
            memoryGradient[x] += memoryGradient[y] * (1 - tanh * tanh);
        }
    }
}
