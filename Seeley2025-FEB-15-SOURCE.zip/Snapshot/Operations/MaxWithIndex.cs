﻿namespace Workshop.Operations
{
    public class MaxWithIndex : Operation
    {
        public List<int> xs;
        public int y;
        public int index;

        public MaxWithIndex(List<int> xs, int y, int index)
            : base(xs, [y, index])
        {
            this.xs = xs;
            this.y = y;
            this.index = index;
        }

        public override void Forward(float[] memory)
        {
            float max = float.MinValue;
            int maxIndex = -1;
            for (int i = 0; i < xs.Count; i++)
            {
                int x = xs[i];
                if (memory[x] > max)
                {
                    max = memory[x];
                    maxIndex = i;
                }
            }
            memory[y] = max;
            memory[index] = maxIndex;
        }

        public override void Gradient(float[] memory, float[] memoryGradient)
        {
            int maxIndex = (int)memory[index];
            for (int i = 0; i < xs.Count; i++)
            {
                int x = xs[i];
                if (i == maxIndex)
                {
                    memoryGradient[x] += memoryGradient[y];
                }
                else
                {
                    memoryGradient[x] += 0;
                }
            }
        }
    }
}
