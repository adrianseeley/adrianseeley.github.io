﻿namespace Workshop.Operations
{
    public class Sigmoid : Operation
    {
        public int x;
        public int y;

        public Sigmoid(int x, int y)
            : base([x], [y])
        {
            this.x = x;
            this.y = y;
        }

        public override void Forward(float[] memory)
        {
            memory[y] = 1 / (1 + MathF.Exp(-memory[x]));
        }

        public override void Gradient(float[] memory, float[] memoryGradient)
        {
            float yValue = memory[y];
            memoryGradient[x] += memoryGradient[y] * yValue * (1 - yValue);
        }
    }
}
