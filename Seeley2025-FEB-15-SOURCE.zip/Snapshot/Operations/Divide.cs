﻿namespace Workshop.Operations
{
    public class Divide : Operation
    {
        public int a;
        public int b;
        public int y;

        public Divide(int a, int b, int y)
            : base([a, b], [y])
        {
            this.a = a;
            this.b = b;
            this.y = y;
        }

        public override void Forward(float[] memory)
        {
            memory[y] = memory[a] / memory[b];
        }

        public override void Gradient(float[] memory, float[] memoryGradient)
        {
            memoryGradient[a] += memoryGradient[y] / memory[b];
            memoryGradient[b] -= memoryGradient[y] * memory[a] / MathF.Pow(memory[b], 2);
        }
    }
}
