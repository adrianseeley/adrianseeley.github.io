﻿namespace Workshop.Operations
{
    public class Average : Operation
    {
        public List<int> xs;
        public int y;

        public Average(List<int> xs, int y)
            : base(xs, [y])
        {
            this.xs = xs;
            this.y = y;

        }

        public override void Forward(float[] memory)
        {
            float sum = 0;
            foreach (int x in xs)
            {
                sum += memory[x];
            }
            memory[y] = sum / (float)xs.Count;
        }

        public override void Gradient(float[] memory, float[] memoryGradient)
        {
            float gradientValue = 1f / (float)xs.Count;
            foreach (int x in xs)
            {
                memoryGradient[x] += gradientValue;
            }
        }
    }
}
