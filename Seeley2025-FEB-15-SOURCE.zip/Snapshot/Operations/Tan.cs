﻿namespace Workshop.Operations
{
    public class Tan : Operation
    {
        public int x;
        public int y;

        public Tan(int x, int y)
            : base([x], [y])
        {
            this.x = x;
            this.y = y;
        }

        public override void Forward(float[] memory)
        {
            memory[y] = MathF.Tan(memory[x]);
        }

        public override void Gradient(float[] memory, float[] memoryGradient)
        {
            float cos = MathF.Cos(memory[x]);
            memoryGradient[x] += memoryGradient[y] / (cos * cos);
        }
    }
}
