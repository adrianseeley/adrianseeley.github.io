﻿namespace Workshop.Operations
{
    public class ReLu : Operation
    {
        public int x;
        public int y;

        public ReLu(int x, int y)
            : base([x], [y])
        {
            this.x = x;
            this.y = y;
        }

        public override void Forward(float[] memory)
        {
            memory[y] = MathF.Max(0, memory[x]);
        }

        public override void Gradient(float[] memory, float[] memoryGradient)
        {
            memoryGradient[x] += memoryGradient[y] * (memory[x] > 0 ? 1 : 0);
        }
    }
}
