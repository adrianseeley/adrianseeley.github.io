﻿namespace Workshop.Operations
{
    public class MinWithIndex : Operation
    {
        public List<int> xs;
        public int y;
        public int index;

        public MinWithIndex(List<int> xs, int y, int index)
            : base(xs, [y, index])
        {
            this.xs = xs;
            this.y = y;
            this.index = index;
        }

        public override void Forward(float[] memory)
        {
            float min = float.MaxValue;
            int minIndex = -1;
            for (int i = 0; i < xs.Count; i++)
            {
                int x = xs[i];
                if (memory[x] < min)
                {
                    min = memory[x];
                    minIndex = i;
                }
            }
            memory[y] = min;
            memory[index] = minIndex;
        }

        public override void Gradient(float[] memory, float[] memoryGradient)
        {
            int minIndex = (int)memory[index];
            for (int i = 0; i < xs.Count; i++)
            {
                int x = xs[i];
                if (i == minIndex)
                {
                    memoryGradient[x] += memoryGradient[y];
                }
                else
                {
                    memoryGradient[x] += 0;
                }
            }
        }
    }
}
