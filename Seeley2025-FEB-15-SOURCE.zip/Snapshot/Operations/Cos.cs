﻿namespace Workshop.Operations
{
    public class Cos : Operation
    {
        public int x;
        public int y;

        public Cos(int x, int y)
            : base([x], [y])
        {
            this.x = x;
            this.y = y;
        }

        public override void Forward(float[] memory)
        {
            memory[y] = MathF.Cos(memory[x]);
        }

        public override void Gradient(float[] memory, float[] memoryGradient)
        {
            memoryGradient[x] -= memoryGradient[y] * MathF.Sin(memory[x]);
        }
    }
}
