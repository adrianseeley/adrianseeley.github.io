﻿namespace Workshop.Operations
{
    public abstract class Operation
    {
        public List<int> inputs;
        public List<int> outputs;

        public Operation(List<int> inputs, List<int> outputs)
        {
            this.inputs = inputs;
            this.outputs = outputs;
        }

        public abstract void Forward(float[] memory);
        public abstract void Gradient(float[] memory, float[] memoryGradient);
    }
}
