﻿namespace Workshop.Operations
{
    public class Multiply : Operation
    {
        public List<int> xs;
        public int y;

        public Multiply(List<int> xs, int y)
            : base(xs, [y])
        {
            this.xs = xs;
            this.y = y;
        }

        public override void Forward(float[] memory)
        {
            float product = 1;
            foreach (int x in xs)
            {
                product *= memory[x];
            }
            memory[y] = product;
        }

        public override void Gradient(float[] memory, float[] memoryGradient)
        {
            float yGradient = memoryGradient[y] * memory[y];
            foreach (int x in xs)
            {
                if (memory[x] == 0f)
                {
                    memoryGradient[x] += 0;
                }
                else
                {
                    memoryGradient[x] += yGradient / memory[x];
                }
            }
        }
    }
}
