﻿namespace Workshop.Operations
{
    public class Max : Operation
    {
        public List<int> xs;
        public int y;

        public Max(List<int> xs, int y)
            : base(xs, [y])
        {
            this.xs = xs;
            this.y = y;
        }

        public override void Forward(float[] memory)
        {
            float max = float.MinValue;
            foreach (int x in xs)
            {
                max = MathF.Max(max, memory[x]);
            }
            memory[y] = max;
        }

        public override void Gradient(float[] memory, float[] memoryGradient)
        {
            float max = memory[y];
            foreach (int x in xs)
            {
                if (memory[x] == max)
                {
                    memoryGradient[x] += memoryGradient[y];
                }
                else
                {
                    memoryGradient[x] += 0;
                }
            }
        }
    }
}
