﻿namespace Workshop.Operations
{
    public class Plus : Operation
    {
        public List<int> xs;
        public int y;

        public Plus(List<int> xs, int y)
            : base(xs, [y])
        {
            this.xs = xs;
            this.y = y;
        }

        public override void Forward(float[] memory)
        {
            float sum = 0;
            foreach (int x in xs)
            {
                sum += memory[x];
            }
            memory[y] = sum;
        }

        public override void Gradient(float[] memory, float[] memoryGradient)
        {
            foreach (int x in xs)
            {
                memoryGradient[x] += memoryGradient[y];
            }
        }
    }
}
