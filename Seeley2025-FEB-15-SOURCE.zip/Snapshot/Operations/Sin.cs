﻿namespace Workshop.Operations
{
    public class Sin : Operation
    {
        public int x;
        public int y;

        public Sin(int x, int y)
            : base([x], [y])
        {
            this.x = x;
            this.y = y;
        }

        public override void Forward(float[] memory)
        {
            memory[y] = MathF.Sin(memory[x]);
        }

        public override void Gradient(float[] memory, float[] memoryGradient)
        {
            memoryGradient[x] += memoryGradient[y] * MathF.Cos(memory[x]);
        }
    }
}
