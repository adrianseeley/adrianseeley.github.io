﻿namespace Workshop
{

    public class Sample
    {
        public float[] input;
        public float[] output;
        public int argmax;

        public Sample(float[] input, float[] output)
        {
            this.input = input;
            this.output = output;
            for (int i = 0; i < input.Length; i++)
            {
                if (float.IsNaN(input[i]))
                {
                    throw new Exception("NaN");
                }
            }
            for (int i = 0; i < output.Length; i++)
            {
                if (float.IsNaN(output[i]))
                {
                    throw new Exception("NaN");
                }
            }
            argmax = Utility.Argmax(output);
        }

        public static List<Sample> Normalize(List<Sample> samples)
        {
            float[] inputMins = new float[samples[0].input.Length];
            float[] inputMaxs = new float[samples[0].input.Length];
            float[] outputMins = new float[samples[0].output.Length];
            float[] outputMaxs = new float[samples[0].output.Length];
            foreach (Sample sample in samples)
            {
                for (int i = 0; i < sample.input.Length; i++)
                {
                    inputMins[i] = Math.Min(inputMins[i], sample.input[i]);
                    inputMaxs[i] = Math.Max(inputMaxs[i], sample.input[i]);
                }
                for (int i = 0; i < sample.output.Length; i++)
                {
                    outputMins[i] = Math.Min(outputMins[i], sample.output[i]);
                    outputMaxs[i] = Math.Max(outputMaxs[i], sample.output[i]);
                }
            }
            float[] inputRanges = new float[inputMins.Length];
            float[] outputRanges = new float[outputMins.Length];
            for (int i = 0; i < inputMins.Length; i++)
            {
                inputRanges[i] = inputMaxs[i] - inputMins[i];
            }
            for (int i = 0; i < outputMins.Length; i++)
            {
                outputRanges[i] = outputMaxs[i] - outputMins[i];
            }
            List<Sample> normalized = new List<Sample>();
            foreach (Sample sample in samples)
            {
                float[] normalizedInput = new float[sample.input.Length];
                float[] normalizedOutput = new float[sample.output.Length];
                for (int i = 0; i < sample.input.Length; i++)
                {
                    if (inputRanges[i] == 0)
                    {
                        normalizedInput[i] = 0;
                    }
                    else
                    {
                        normalizedInput[i] = (sample.input[i] - inputMins[i]) / inputRanges[i];
                    }
                }
                for (int i = 0; i < sample.output.Length; i++)
                {
                    if (outputRanges[i] == 0)
                    {
                        normalizedOutput[i] = 0;
                    }
                    else
                    {
                        normalizedOutput[i] = (sample.output[i] - outputMins[i]) / outputRanges[i];
                    }
                }
                normalized.Add(new Sample(normalizedInput, normalizedOutput));
            }
            return normalized;
        }
    }
}