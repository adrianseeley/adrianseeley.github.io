﻿using Workshop.Batching;
using Workshop.GradientModifying;
namespace Workshop
{
    internal class Program
    {
        public static void Main(string[] args)
        {
            string csvDir = "./csv";
            if (Directory.Exists(csvDir))
            {
                Directory.Delete(csvDir, recursive: true);
            }
            Directory.CreateDirectory(csvDir);

            Dataset dataset = Data.MNIST("d:/data/mnist_train.csv", "d:/data/mnist_test.csv");
            (Dataset train, Dataset test) = dataset.Split(60000);

            List<(int layerCount, int neuronCount, int neuronInputCount, int order)> configurations = new List<(int layerCount, int neuronCount, int neuronInputCount, int order)>();
            for (int layerCount = 1; layerCount <= 100; layerCount += 10)
            {
                for (int neuronCount = 1; neuronCount <= 100; neuronCount += 10)
                {
                    for (int neuronInputCount = 1; neuronInputCount <= 100; neuronInputCount += 10)
                    {
                        configurations.Add((layerCount, neuronCount, neuronInputCount, layerCount * neuronCount * neuronInputCount));
                    }
                }
            }
            configurations.Sort((a, b) => a.order.CompareTo(b.order));

            TextWriter aggCSV = new StreamWriter($"{csvDir}/{dataset.name}-agg.csv");
            aggCSV.WriteLine("layerCount,neuronCount,neuronInputCount,trainMACE,testMACE,trainARGM,testARGM");
            aggCSV.Flush();

            foreach ((int layerCount, int neuronCount, int neuronInputCount, int order) configuration in configurations)
            {
                string configurationName = $"L{configuration.layerCount}N{configuration.neuronCount}I{configuration.neuronInputCount}";

                Graph graph = new Graph();
                VariableInitializer variableInitializer = new VariableInitializer(-0.0001f, 0.0001f);
                int leakiness = graph.Constant(0.01f);
                List<int> graphInputs = graph.GraphInputs(dataset.inputLength);
                (List<int> finalLayerOutputs, List<int> allOutputs) = graph.RandomConnectedNeuronBlock(
                   vector: graphInputs,
                   layerCount: configuration.layerCount,
                   neuronCount: configuration.neuronCount,
                   neuronInputCount: configuration.neuronInputCount,
                   weightInitializer: variableInitializer,
                   biasInitializer: variableInitializer,
                   activationFunction: (x) => graph.LeakyReLu(x, leakiness)
               );
                List<int> prediction = graph.NeuronLayer(
                    vector: allOutputs,
                    neuronCount: dataset.outputLength,
                    weightInitializer: variableInitializer,
                    biasInitializer: variableInitializer,
                    activationFunction: (x) => graph.LeakyReLu(x, leakiness)
                );
                graph.GraphOutputs(prediction);

                graph.Compile();
                float[] memory = graph.CreateMemory();

                int threadCount = 8;
                int lastMeasure = -10000000;
                int measureEvery = 50000;
                int stopAt = 100000;
                TextWriter csv = new StreamWriter($"{csvDir}/{dataset.name}-{configurationName}.csv");
                csv.WriteLine("epoch,gradientsComputed,batchMACE,trainMACE,testMACE,trainARGM,testARGM");
                Optimizer.Parallel(
                    graph: graph,
                    memory: memory,
                    samples: train.samples,
                    batcher: new RandomMiniBatcher(256),
                    loss: Loss.Squared,
                    dropoutRate: null,
                    weightDecay: 0.9999f,
                    gradientModifiers: [
                        new Adam(),
                        new LearningRate(0.001f)
                    ],
                    epochCallback: (int epoch, int gradientsComputed, float batchMACE, Graph graph, float[] memory, GradientModifier[]? gradientModifiers) =>
                    {
                        Console.Write($"{dataset.name} {configurationName} Epoch {epoch} GC {gradientsComputed} Batch MACE {batchMACE} ");
                        if (gradientsComputed - lastMeasure > measureEvery)
                        {
                            lastMeasure = gradientsComputed;
                            (float trainMACE, float trainARGM) = Fitness.MACEandARGMErrorParallel(graph, memory, train.samples, threadCount);
                            Console.Write($"Train MACE {trainMACE} Train ARGM {trainARGM} ");
                            (float testMACE, float testARGM) = Fitness.MACEandARGMErrorParallel(graph, memory, test.samples, threadCount);
                            Console.Write($"Test MACE {testMACE} Test ARGM {testARGM} ");
                            csv.WriteLine($"{epoch},{gradientsComputed},{batchMACE},{trainMACE},{testMACE},{trainARGM},{testARGM}");
                            csv.Flush();
                            if (gradientsComputed > stopAt)
                            {
                                aggCSV.WriteLine($"{configuration.layerCount},{configuration.neuronCount},{configuration.neuronInputCount},{trainMACE},{testMACE},{trainARGM},{testARGM}");
                                aggCSV.Flush();
                                Console.WriteLine();
                                return true;
                            }
                        }
                        Console.WriteLine();
                        return false;
                    },
                    threadCount: threadCount
                );
                csv.Close();
            }
            aggCSV.Close();
        }
    }
}
