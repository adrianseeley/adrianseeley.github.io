using Workshop.Batching;
using Workshop.GradientModifying;

namespace Workshop
{
    public delegate bool EpochCallback(int epoch, int gradientsComputed, float batchMACE, Graph graph, float[] memory, GradientModifier[]? gradientModifiers);

    public static class Optimizer
    {
        /*public static void Serial(Graph graph, float[] memory, Sample[] samples, Batcher batcher, LossFunction loss, GradientModifier[]? gradientModifiers = null, float[]? sampleWeights = null, int? maxEpochs = null, EpochCallback? epochCallback = null)
        {
            // if sample weights arent provided, create a uniformed weighting
            if (sampleWeights == null)
            {
                sampleWeights = new float[samples.Length];
                for (int i = 0; i < samples.Length; i++)
                {
                    sampleWeights[i] = 1.0f;
                }
            }

            // if gradient modifiers are provided call setup for them
            if (gradientModifiers != null)
            {
                for (int i = 0; i < gradientModifiers.Length; i++)
                {
                    gradientModifiers[i].Setup(memory.Length);
                }
            }

            // create graph parameters
            float[] memoryGradient = graph.CreateMemoryGradient();
            float[] memoryGradientGradientAverage = new float[memoryGradient.Length];
            float memoryGradientAverageWeightSum = 0.0f;
            float[] output = new float[graph.graphOutputs.Count];
            float[] outputGradient = new float[output.Length];

            // iterate through epoch
            int epochs = (maxEpochs.HasValue ? maxEpochs.Value : int.MaxValue);
            int gradientsComputed = 0;
            for (int epoch = 0; epoch < epochs; epoch++)
            {
                // get a batch of samples
                (Sample[] samples, float[] weights) batch = batcher.GetBatch(epoch, (samples, sampleWeights));

                // reset the memory gradient sum for this batch
                Array.Clear(memoryGradientGradientAverage, 0, memoryGradientGradientAverage.Length);
                memoryGradientAverageWeightSum = 0.0f;

                // iterate though batch
                int total = batch.samples.Where((sample, i) => batch.weights[i] > 0f).Count();
                int done = 0;
                for (int i = 0; i < batch.samples.Length; i++)
                {
                    // get the sample and its batched weight
                    Sample sample = batch.samples[i];
                    float weight = batch.weights[i];

                    // dont compute left out samples
                    if (weight <= 0f)
                    {
                        continue;
                    }

                    done++;

                    // forward pass
                    Console.Write($"\rEpoch {epoch} FWD: {done}/{total}");
                    graph.Forward(memory, sample.input, output);

                    // compute the loss into the output gradient
                    Console.Write($"\rEpoch {epoch} LOS: {done}/{total}");
                    loss(output, sample.output, outputGradient);

                    // backpropagate the gradient
                    Console.Write($"\rEpoch {epoch} GRD: {done}/{total}");
                    graph.Gradient(memory, memoryGradient, outputGradient);
                    gradientsComputed++;

                    // accumulate the batch weighted gradient
                    Console.Write($"\rEpoch {epoch} ACC: {done}/{total}");
                    for (int j = 0; j < memoryGradientGradientAverage.Length; j++)
                    {
                        memoryGradientGradientAverage[j] += memoryGradient[j] * weight;
                    }
                    memoryGradientAverageWeightSum += weight;
                }

                Console.WriteLine($"\rEpoch {epoch} DON: {done}/{total}");

                // if there is no sum weight, skip the update
                if (memoryGradientAverageWeightSum == 0.0f)
                {
                    continue;
                }

                // weighted average the gradient
                for (int i = 0; i < memoryGradientGradientAverage.Length; i++)
                {
                    memoryGradientGradientAverage[i] /= memoryGradientAverageWeightSum;
                }

                // apply gradient modifiers
                if (gradientModifiers != null)
                {
                    for (int i = 0; i < gradientModifiers.Length; i++)
                    {
                        gradientModifiers[i].Modify(epoch, memory, memoryGradientGradientAverage);
                    }
                }

                // apply gradient
                for (int i = 0; i < memoryGradientGradientAverage.Length; i++)
                {
                    memory[i] -= memoryGradientGradientAverage[i];
                }

                // check if the epoch callback returns false
                if (epochCallback != null && epochCallback(epoch, gradientsComputed, graph, memory, gradientModifiers))
                {
                    break;
                }
            }
        }*/

        public static void Parallel(Graph graph, float[] memory, Sample[] samples, Batcher batcher, LossFunction loss, int threadCount, float? weightDecay = null, float? dropoutRate = null, GradientModifier[]? gradientModifiers = null, float[]? sampleWeights = null, int? maxEpochs = null, EpochCallback? epochCallback = null)
        {
            // if sample weights arent provided, create a uniformed weighting
            if (sampleWeights == null)
            {
                sampleWeights = new float[samples.Length];
                for (int i = 0; i < samples.Length; i++)
                {
                    sampleWeights[i] = 1.0f;
                }
            }

            // if gradient modifiers are provided call setup for them
            if (gradientModifiers != null)
            {
                for (int i = 0; i < gradientModifiers.Length; i++)
                {
                    gradientModifiers[i].Setup(memory.Length);
                }
            }

            // make copies of memory
            List<float[]> threadMemories = new List<float[]>();
            for (int i = 0; i < threadCount; i++)
            {
                threadMemories.Add((float[])memory.Clone());
            }

            // create memory gradients for each thread
            List<float[]> threadMemoryGradients = new List<float[]>();
            for (int i = 0; i < threadCount; i++)
            {
                threadMemoryGradients.Add(graph.CreateMemoryGradient());
            }

            // create thread outputs
            List<float[]> threadOutputs = new List<float[]>();
            for (int i = 0; i < threadCount; i++)
            {
                threadOutputs.Add(new float[graph.graphOutputs.Count]);
            }

            // create thread output gradients
            List<float[]> threadOutputGradients = new List<float[]>();
            for (int i = 0; i < threadCount; i++)
            {
                threadOutputGradients.Add(new float[graph.graphOutputs.Count]);
            }

            // create gradient average and sum
            float[] memoryGradientGradientAverage = graph.CreateMemoryGradient();
            float memoryGradientAverageWeightSum = 0.0f;

            // create batch holster and iterator
            (Sample[] samples, float[] weights)? batch = null;
            int batchIndex = -1;

            // tracking
            int gradientsComputed = 0;
            int batchDone = 0;
            int batchSamplesWithWeight = 0;
            float batchMACE = 0f;

            // create synchronization objects
            object averageLock = new object();
            Barrier startBarrier = new Barrier(threadCount + 1);
            Barrier endBarrier = new Barrier(threadCount + 1);
            bool complete = false;

            // create threads
            Thread[] threads = new Thread[threadCount];
            for (int threadIndex = 0; threadIndex < threadCount; threadIndex++)
            {
                int closureThreadIndex = threadIndex;
                Thread thread = new Thread(() =>
                {
                    // get locals
                    float[] threadMemory = threadMemories[closureThreadIndex];
                    float[] threadMemoryGradient = threadMemoryGradients[closureThreadIndex];
                    float[] threadOutput = threadOutputs[closureThreadIndex];
                    float[] threadOutputGradient = threadOutputGradients[closureThreadIndex];

                    for (; ; )
                    {
                        // wait at start barrier
                        startBarrier.SignalAndWait();

                        if (complete)
                        {
                            return;
                        }

                        // null check batch
                        if (batch == null)
                        {
                            throw new Exception("Batch is null");
                        }
                        Sample[] samples = batch.Value.samples;
                        float[] weights = batch.Value.weights;

                        // loop until batch is done
                        for (; ; )
                        {
                            // get next batch index
                            int safeBatchIndex = Interlocked.Increment(ref batchIndex);

                            // if its past the end we are done go wait at end barrier
                            if (safeBatchIndex >= samples.Length)
                            {
                                break;
                            }

                            // get sample and weight from batch
                            Sample sample = samples[safeBatchIndex];
                            float weight = weights[safeBatchIndex];

                            // if the sample has no weight continue
                            if (weight <= 0f)
                            {
                                continue;
                            }

                            // forward pass
                            if (dropoutRate == null)
                            {
                                graph.Forward(threadMemory, sample.input, threadOutput);
                            }
                            else
                            {
                                graph.ForwardDropout(threadMemory, sample.input, threadOutput, dropoutRate.Value);
                            }

                            // compute the loss into the output gradient
                            loss(threadOutput, sample.output, threadOutputGradient);

                            // backpropagate the gradient
                            graph.Gradient(threadMemory, threadMemoryGradient, threadOutputGradient);

                            // lock the average and sum
                            lock (averageLock)
                            {
                                // accumulate the batch weighted gradient
                                for (int j = 0; j < memoryGradientGradientAverage.Length; j++)
                                {
                                    memoryGradientGradientAverage[j] += threadMemoryGradient[j] * weight;
                                }
                                memoryGradientAverageWeightSum += weight;

                                // tally gradient computation
                                gradientsComputed++;

                                // tally batch done
                                batchDone++;

                                // tally batch maca
                                for (int j = 0; j < threadOutput.Length; j++)
                                {
                                    batchMACE += Math.Abs(threadOutput[j] - sample.output[j]);
                                }
                            }
                        }

                        // wait at end barrier
                        endBarrier.SignalAndWait();
                    }
                });
                threads[threadIndex] = thread;
                thread.Start();
            }

            // iterate through epoch
            int epochs = (maxEpochs.HasValue ? maxEpochs.Value : int.MaxValue);
            for (int epoch = 0; epoch < epochs; epoch++)
            {
                // get a batch of samples
                batch = batcher.GetBatch(epoch, (samples, sampleWeights));

                // count samples with weight
                batchSamplesWithWeight = 0;
                for (int i = 0; i < batch.Value.weights.Length; i++)
                {
                    if (batch.Value.weights[i] > 0f)
                    {
                        batchSamplesWithWeight++;
                    }
                }

                // reset the memory gradient sum for this batch
                Array.Clear(memoryGradientGradientAverage, 0, memoryGradientGradientAverage.Length);
                memoryGradientAverageWeightSum = 0.0f;
                batchDone = 0;
                batchIndex = -1;
                batchMACE = 0f;

                // copy memory to threads
                for (int i = 0; i < threadCount; i++)
                {
                    Array.Copy(memory, threadMemories[i], memory.Length);
                }

                // signal thread starts
                startBarrier.SignalAndWait();

                // wait for end barrier
                endBarrier.SignalAndWait();

                // if there is no sum weight, skip the update
                if (memoryGradientAverageWeightSum == 0.0f)
                {
                    continue;
                }

                // weighted average the gradient
                for (int i = 0; i < memoryGradientGradientAverage.Length; i++)
                {
                    memoryGradientGradientAverage[i] /= memoryGradientAverageWeightSum;
                }

                // apply gradient modifiers
                if (gradientModifiers != null)
                {
                    for (int i = 0; i < gradientModifiers.Length; i++)
                    {
                        gradientModifiers[i].Modify(epoch, memory, memoryGradientGradientAverage);
                    }
                }

                // apply gradient
                for (int i = 0; i < memoryGradientGradientAverage.Length; i++)
                {
                    memory[i] -= memoryGradientGradientAverage[i];
                }

                // if there is a weight decay, decay weights
                if (weightDecay != null)
                {
                    for (int i = 0; i < memory.Length; i++)
                    {
                        memory[i] *= weightDecay.Value;
                    }
                }

                // check if the epoch callback returns false
                if (epochCallback != null && epochCallback(epoch, gradientsComputed, batchMACE / ((float)batchDone * (float)graph.graphOutputs.Count), graph, memory, gradientModifiers))
                {
                    break;
                }
            }

            // mark complete
            complete = true;

            // signal threads to hit complete wall
            startBarrier.SignalAndWait();

            // threads will destroy
        }
    }
}
