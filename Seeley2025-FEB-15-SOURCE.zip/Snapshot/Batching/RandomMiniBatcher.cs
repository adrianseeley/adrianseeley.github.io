﻿namespace Workshop.Batching
{
    public class RandomMiniBatcher : Batcher
    {
        public Random random;
        public int size;

        public RandomMiniBatcher(int size)
        {
            random = new Random();
            this.size = size;
        }

        public override (Sample[] samples, float[] weights) GetBatch(int epoch, (Sample[] samples, float[] weights) data)
        {
            float[] weights = new float[data.samples.Length];
            for (int i = 0; i < size; i++)
            {
                weights[random.Next(data.samples.Length)] += data.weights[i];
            }
            return (data.samples, weights);
        }
    }
}
