﻿namespace Workshop.Batching
{
    public class FullBatcher : Batcher
    {
        public override (Sample[] samples, float[] weights) GetBatch(int epoch, (Sample[] samples, float[] weights) data)
        {
            return data;
        }
    }
}
