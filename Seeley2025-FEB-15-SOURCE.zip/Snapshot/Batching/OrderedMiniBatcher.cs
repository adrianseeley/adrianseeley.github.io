﻿namespace Workshop.Batching
{
    public class OrderedMiniBatcher : Batcher
    {
        public int size;

        public OrderedMiniBatcher(int size)
        {
            this.size = size;
        }

        public override (Sample[] samples, float[] weights) GetBatch(int epoch, (Sample[] samples, float[] weights) data)
        {
            float[] weights = new float[data.samples.Length];
            int start = epoch * size % data.samples.Length;
            for (int i = 0; i < size; i++)
            {
                int index = (start + i) % data.samples.Length;
                weights[index] += data.weights[index];
            }
            return (data.samples, weights);
        }
    }
}
