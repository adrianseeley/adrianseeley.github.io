﻿namespace Workshop.Batching
{
    public class BootstrapBatcher : Batcher
    {
        public Random random;

        public BootstrapBatcher()
        {
            random = new Random();
        }

        public override (Sample[] samples, float[] weights) GetBatch(int epoch, (Sample[] samples, float[] weights) data)
        {
            float[] weights = new float[data.samples.Length];
            for (int i = 0; i < data.samples.Length; i++)
            {
                weights[random.Next(data.samples.Length)] += data.weights[i];
            }
            return (data.samples, weights);
        }
    }
}
