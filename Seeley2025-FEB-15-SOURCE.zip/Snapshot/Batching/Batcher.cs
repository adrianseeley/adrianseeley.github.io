﻿namespace Workshop.Batching
{
    public abstract class Batcher
    {
        public abstract (Sample[] samples, float[] weights) GetBatch(int epoch, (Sample[] samples, float[] weights) data);
    }
}
