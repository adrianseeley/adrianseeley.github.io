namespace Workshop
{
    public class VariableInitializer
    {
        public float min;
        public float max;
        public float range;

        public VariableInitializer(float min, float max)
        {
            this.min = min;
            this.max = max;
            this.range = max - min;
        }

        public float Next(Random random)
        {
            return random.NextSingle() * range + min;
        }
    }
}