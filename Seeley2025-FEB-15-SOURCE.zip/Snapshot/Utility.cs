﻿namespace Workshop
{
    public class Utility
    {
        public static int Argmax(float[] values)
        {
            int argmax = 0;
            float max = values[0];
            for (int i = 1; i < values.Length; i++)
            {
                if (values[i] > max)
                {
                    argmax = i;
                    max = values[i];
                }
            }
            return argmax;
        }
    }
}