namespace Workshop
{
    public static class Data
    {
        public static Dataset MNIST(string filenameTrain, string filenameTest, int limit = -1)
        {
            // read train
            List<Sample> samples = new List<Sample>();
            string[] lines = File.ReadAllLines(filenameTrain);
            for (int lineIndex = 1; lineIndex < lines.Length; lineIndex++)
            {
                string line = lines[lineIndex].Trim();
                if (line.Length == 0)
                {
                    continue;
                }
                string[] parts = line.Split(',');
                int labelInt = int.Parse(parts[0]);
                float[] labelOneHot = new float[10];
                labelOneHot[labelInt] = 1;
                float[] input = new float[parts.Length - 1];
                for (int i = 1; i < parts.Length; i++)
                {
                    input[i - 1] = float.Parse(parts[i]);
                }
                samples.Add(new Sample(input, labelOneHot));
                if (limit != -1 && samples.Count >= limit)
                {
                    break;
                }
            }

            // read test (we pile it on if required)
            if (limit == -1 || samples.Count < limit)
            {
                lines = File.ReadAllLines(filenameTest);
                for (int lineIndex = 1; lineIndex < lines.Length; lineIndex++)
                {
                    string line = lines[lineIndex].Trim();
                    if (line.Length == 0)
                    {
                        continue;
                    }
                    string[] parts = line.Split(',');
                    int labelInt = int.Parse(parts[0]);
                    float[] labelOneHot = new float[10];
                    labelOneHot[labelInt] = 1;
                    float[] input = new float[parts.Length - 1];
                    for (int i = 1; i < parts.Length; i++)
                    {
                        input[i - 1] = float.Parse(parts[i]);
                    }
                    samples.Add(new Sample(input, labelOneHot));
                    if (limit != -1 && samples.Count >= limit)
                    {
                        break;
                    }
                }
            }

            samples = Sample.Normalize(samples);
            return new Dataset("MNIST", samples.ToArray());
        }
    }
}