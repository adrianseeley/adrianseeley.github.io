﻿namespace Workshop
{
    public class Dataset
    {
        public string name;
        public Sample[] samples;
        public int inputLength;
        public int outputLength;

        public Dataset(string name, Sample[] samples)
        {
            this.name = name;
            this.samples = samples;
            this.inputLength = samples[0].input.Length;
            this.outputLength = samples[0].output.Length;
        }

        public (Dataset train, Dataset test) Split(int trainCount)
        {
            Sample[] trainSamples = samples.Take(trainCount).ToArray();
            Sample[] testSamples = samples.Skip(trainCount).ToArray();
            string splitName = $"{name}-T{trainSamples.Length}-t{testSamples.Length}";
            return (new Dataset($"{splitName}-T", trainSamples), new Dataset($"{splitName}-t", testSamples));
        }
    }
}